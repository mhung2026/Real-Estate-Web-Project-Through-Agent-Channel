module.exports = {
    images: {
        domains: [
            "shopify.com",
            "cdn.shopify.com"
        ]
    }
}