import BootstrapProvider from '@bootstrap-styled/provider';

export * from "@bootstrap-styled/v4";
export default BootstrapProvider
