import styled, {space} from "@styled";

export const PromotionsWrap = styled.section`
  ${space}
`