import styled, {space} from "@styled";

export const BlogWrap = styled.section`
  ${space}
`