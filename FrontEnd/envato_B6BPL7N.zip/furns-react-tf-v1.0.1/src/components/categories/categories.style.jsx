import styled, {space} from "@styled";

export const CategoriesWrap = styled.section`
  ${space}
`