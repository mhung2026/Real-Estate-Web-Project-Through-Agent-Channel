import SliderOne from "@components/slider/home-1";
import SliderTwo from "@components/slider/home-2";

export {SliderOne, SliderTwo}