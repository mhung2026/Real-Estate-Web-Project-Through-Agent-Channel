import ProductsTab from "@components/product/feed/products-tab";
import RelatedProducts from "@components/product/feed/related-products";

export {ProductsTab, RelatedProducts}