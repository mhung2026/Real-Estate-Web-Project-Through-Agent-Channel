import logout from "@utils/auth/logout";

export { logout };
